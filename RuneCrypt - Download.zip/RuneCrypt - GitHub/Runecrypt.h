#ifndef RUNECRYPT_H
#define RUNECRYPT_H

void lineSpace1();
void welcomeRunecrypt();
void helpScript();
void quitScript();
void continueScript();
void encryptScript();
void decryptScript();
#endif