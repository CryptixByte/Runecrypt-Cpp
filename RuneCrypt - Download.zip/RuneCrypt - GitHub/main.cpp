#include <iostream>
#include "Runecrypt.h"
using namespace std;

int main()
{
  welcomeRunecrypt();
}
